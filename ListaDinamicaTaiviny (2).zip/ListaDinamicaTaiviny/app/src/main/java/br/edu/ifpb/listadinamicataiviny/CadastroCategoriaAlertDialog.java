package br.edu.ifpb.listadinamicataiviny;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class CadastroCategoriaAlertDialog extends DialogFragment {
    private EditText etEntradaCategoria;
    private  Cadastrolistener cadastrolistener;


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder =new AlertDialog.Builder(getActivity());

        // o Layout Inflater ira  sobrepor o layout
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View formCadastroCategoria = inflater.inflate(R.layout.formcadastrocategoria_alertdialog, null);

        etEntradaCategoria = formCadastroCategoria.findViewById(R.id.etEntradaCategoria);

        builder.setTitle("Nova Categoria:")
                        .setView(formCadastroCategoria)
                        .setPositiveButton("Finalizar", new DialogInterface.OnClickListener(){
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        String categoria = String.valueOf(etEntradaCategoria.getText());
                                        cadastrolistener.cadastrarCategoria(categoria);
                                        Log.i("APP", categoria);

                                    }
                                });

        return builder.create();

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            cadastrolistener = (Cadastrolistener) context;

        }catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + "precisa implementar a interface CadastroListener");
        }


    }
    public  interface  Cadastrolistener{
        void cadastrarCategoria(String categoria);
    }
}
